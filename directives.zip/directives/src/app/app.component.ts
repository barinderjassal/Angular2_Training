import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  oddNumbers = [1,3,5,7];
  evenNumbers = [2,4,6,8];
  flag = false;
  displayoddStyle(odd){
    if(odd%2!==0){
      return true;
    }
  }

  displayevenStyle(even){
    if(even%2==0){
      return true;
    }
  }

  displayoddeven(){
   this.flag = !this.flag;
  }
}
