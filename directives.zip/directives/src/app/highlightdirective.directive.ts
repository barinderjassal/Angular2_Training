import { Directive,ElementRef,OnInit,Renderer2,HostListener } from '@angular/core';

@Directive({
  selector: '[appHighlightdirective]'
})
export class HighlightdirectiveDirective implements OnInit {
 


  constructor( private elref:ElementRef,private render:Renderer2) { }

  ngOnInit(){
    //this.elref.nativeElement.style.backgroundColor = 'blue';
    //this.render.setStyle(this.elref.nativeElement,'background-color','red');
  }

  @HostListener('mouseenter') onMouseEnter(){
    this.render.setStyle(this.elref.nativeElement,'background-color','green');
  }

  @HostListener('mouseleave') onmouseleave(){
    this.render.setStyle(this.elref.nativeElement,'background-color','red');
  }

}
