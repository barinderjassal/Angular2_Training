import { Component, DebugElement } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  nameParent: string = 'Barinder';
  counter: number = 0;

  personDetails: any = [
    {name: 'Barinder', age: 27},
    {name: 'Sawan', age: 26},
    {name: 'Nitin', age: 28}
  ];

  //@Input('nameParent')

  incrementCounter() {
    console.log(this.counter++);

  }
  formDataHandler(event) {
    if (event.name != undefined && event.age != undefined)
      this.personDetails.push(event);
  }
}
