import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import {templateFormsModule} from './template-forms.module';
import { AppComponent } from './app.component';

@NgModule({
 
  imports: [
    BrowserModule,
    HttpModule,
    templateFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
