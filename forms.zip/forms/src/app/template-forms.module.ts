import { NgModule } from "@angular/core";
import {CommonModule} from '@angular/common';
import {AppComponent} from './app.component';
import {FormsModule} from '@angular/forms';
import {FooterComponent} from './footer/footer.component';
@NgModule({
 imports:[CommonModule,FormsModule],
 declarations:[AppComponent,FooterComponent],
 exports:[AppComponent]
})
export class templateFormsModule
{

}