import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { AppComponent }  from './app.component';
import { HeroDetailComponent } from './HeroDetailComponent/hero-detail.component';
import { HeroesComponent } from "./HeroesComponent/heroes.component";
import { HeroService } from "./HeroService/hero.service";
import { DashboardComponent } from "./DashboardComponent/dashboard.component";

import { AppRoutingModule }     from './app-routing.module';

@NgModule({
  imports: [ 
    BrowserModule,
    FormsModule, //  import the FormsModule before binding with [(ngModel)]
    AppRoutingModule
  ],
  declarations: [ 
    AppComponent,
    DashboardComponent,
    HeroDetailComponent,
    HeroesComponent
  ],
  providers: [
    HeroService
  ],
  bootstrap: [ AppComponent ]
})

export class AppModule { }
