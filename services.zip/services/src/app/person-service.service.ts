import { Injectable } from '@angular/core';

@Injectable()
export class PersonServiceService {

  records: any = [
    {name: 'Barinder', age: 26},
    {name: 'Sawan', age: 26},
    {name: 'Nitin', age: 27}
  ];
  constructor() { }

  getPersonDetails() {
    return this.records;
  }

}
