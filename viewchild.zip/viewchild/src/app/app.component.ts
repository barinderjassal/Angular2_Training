import { Component,ViewChild,AfterViewInit } from '@angular/core';
import {ChildComponent} from './child/child.component';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent   {
  @ViewChild(ChildComponent) child:ChildComponent
    // ngAfterViewInit(){
    //  //this.childHandler();
    // }

    childHandler(){
      console.log(this.child.whoAmI());
    }
}
