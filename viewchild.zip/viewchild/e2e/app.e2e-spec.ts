import { ViewchildPage } from './app.po';

describe('viewchild App', () => {
  let page: ViewchildPage;

  beforeEach(() => {
    page = new ViewchildPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
